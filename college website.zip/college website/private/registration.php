<?php

require_once('security.php');
require_once('db_connect.php');

if(isset($_POST['register']))
{
	dbConnect();
	
	global $conn;

	if(emailExists($_POST['email']))
	{
		echo "
            <script type=\"text/javascript\">
				window.alert('The Email {$_POST['email']} is already registered.');
            </script>
        ";
	}
	else
	{	
		$userID = createUserID($_POST['firstName'],$_POST['lastName']);
		
		$reg_password = MD5($_POST['password']);
		
		$dob = date("Y-m-d",strtotime($_POST['dateOfBirth']));
		$url = (empty($_POST['URL'])) ? "NULL" : "'".$_POST['URL']."'";
		
		$userID = createUserID($_POST['firstName'],$_POST['lastName']);
		
		$studentSql = 	"INSERT INTO students (user_id,gender,first_name,last_name,dob,url,telephone,address,postal_code,country) 
						VALUES ('".strtoupper($userID)."','".$_POST['gender']."','".$_POST['firstName']."','".$_POST['lastName']."',
						'".$dob."',".$url.",".$_POST['contact'].",'".$_POST['address']."',".$_POST['zipCode'].",'".$_POST['country']."')";
		
		$userSql = "INSERT INTO users (user_id, email, password,access)
				VALUES ('".$userID."','".$_POST['email']."', '".$reg_password."', 'user')";
		
		if($conn->query($studentSql) == null)
		{
			die('Database Error could not enter student data: '.$conn-> error());
		}
		
		if($conn->query($userSql) == null)
		{
			die('Could not enter data: '.$conn-> error());
		}
		
		$httpQuery = array('registration'=>'success','username'=> $userID);
		
		header('Location: login_page.php?'.http_build_query($httpQuery));
		
		
		dbDisconnect();
	}
}

function createUserID(&$first_name,&$last_name)
{
	$firstChar = substr($first_name,0,1);
	$lastFour = substr($last_name,0,4);
	
	$randFive = (string)rand(1,99999);
	
	while(strlen($randFive)<5)
	{
		$randFive = "0".$randFive;
	}
	
	$userID = "$firstChar$lastFour$randFive";
	
	global $conn;
	
	$userNameRepeatSql = "SELECT * FROM users WHERE user_id='".$userID."'";
	
	if(($result = $conn->query($userNameRepeatSql))!=null && mysqli_num_rows($result) > 0)
	{
		return createUserID($first_name,$last_name);
	}
	
	return $userID;
}

function emailExists(&$email)
{
	global $conn;
	
	$emailExistsSql = "SELECT * FROM users WHERE email='".$email."'";
	
	$result = $conn->query($emailExistsSql);
	
	return ($result != null && mysqli_num_rows($result) > 0);
}

?>