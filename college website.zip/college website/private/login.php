<?php

require_once('security.php');
require_once('db_connect.php');

if(isset($_POST['login']))
{
	dbConnect();

	if(accountExists($_POST['username'], $_POST['password']))
	{
		//Login Success
		
		setcookie("login","success",time() + 300);
		setcookie("username",$_POST['username'],time() + 300);
		
		if(isAdmin($_POST['username']))
		{
			setcookie("admin","true",time()+300);
		}
		
		header('Location: index.php');
	}
	else
	{
		$httpQuery = array('login'=>'failed');
		header('Location: login_page.php?'.http_build_query($httpQuery));
	}
}

function accountExists(&$username,&$password)
{
	global $conn;
	
	$passwordEncrypt = MD5($password);
	$accountSql = "SELECT * FROM users WHERE user_id='".$username."' AND password='".$passwordEncrypt."'";
	
	if(($result = $conn->query($accountSql))!=null && mysqli_num_rows($result) > 0)
	{
		return TRUE;
	}
	
	return FALSE;
}

function isAdmin(&$username)
{
	global $conn;
	
	$adminSql = "SELECT * FROM users WHERE user_id='".$username."' AND access='admin'";
	
	if(($result = $conn->query($adminSql))!=null && mysqli_num_rows($result) > 0)
	{
		return TRUE;
	}
	
	return FALSE;
}

?>