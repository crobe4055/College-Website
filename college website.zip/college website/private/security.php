<?php

$servername = "localhost";
$username = "bfost04269";
$password = "one two three";
$database = "bfost04269_college_database";

?>