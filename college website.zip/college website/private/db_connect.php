<?php

require_once('security.php');

function dbConnect()
{
	global $servername,$username,$password,$database,$conn;
	
	if($conn==null)
	{
		//Create Connection
		$conn = new mysqli($servername,$username,$password,$database);

		//Check Connection
		if ($conn->connect_error)
		{
			die("Connection failed: " . $conn->connect_error);
		}
	}
}

function dbDisconnect()
{
	global $conn;
	if($conn)
	{
		$conn->close();
		$conn=null;
	}
}



?>