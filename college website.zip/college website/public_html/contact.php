<?php 
$action=$_REQUEST['action'];
if ($action=="")    // If this is the first time the form has been visited Do nothing.
    {
		
		?>
<!DOCTYPE html>
<html>
<head>

<link rel="stylesheet" type="text/css" href="css/default_theme.css">
	  <script src='js/default.js'></script>
	  <script>
		loadTheme();
	  </script>
</head>

<div id="page">
<body>


    <form  action="" method="POST">
    <input type="hidden" name="action" value="submit">
    Your name:<br>
    <input name="name" type="text" value="" size="30" required /><br>
    Your email:<br>
    <input name="email" type="text" value="" size="30" required /><br>
    Your message:<br>
    <textarea name="message" rows="7" cols="30" style="width:100%" required></textarea><br>
    <button type="submit" value="Send email"/>Send Email</button>
    </form>

</body>
<div>
</html>
		
		
	<?php	
	}
	
	else
	{




$name=$_REQUEST['name']; //name = name given
$email=$_REQUEST['email']; // email = email given.
$message=$_REQUEST['message']; // message = message given.


        $from="From: $name<$email>\r\nReturn-path: $email";
        $subject="Contact Form";
        mail("Foroga_University@gmail.com", $subject, $message, $from);

        echo "Email sent!";

	}
?>


