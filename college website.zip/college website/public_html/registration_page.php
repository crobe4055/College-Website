<!DOCTYPE html>

<?php
	require_once('../private/registration.php');
?>
<html>
	<head>
      <link rel="stylesheet" type="text/css" href="css/default_theme.css">
	  <script src='js/default.js'></script>
	  <script>
		loadTheme();
	  </script>
   </head>

   <body>
   <div id="page">
      <form id="register" method="POST" accept-charset='UTF-8'>
	  <input type="hidden" name="register" value="register"></input>
	  <div style="padding-left:16px">
         <h1>Registration</h1>
		 </div>
		 
         <fieldset>
            <legend>Personal details</legend>
            <p>Note: Please make sure your details are correct before submitting form and that all fields marked with <font color="red">*</font> are completed!.</p>
            <label>Gender
            <input type="radio" name="gender" value="male"> Male
            <input type="radio" name="gender" value="female"> Female
            <input type="radio" name="gender" value="none"> Prefer not to respond
            <br>
            <div>
            <label>First name<font color="red">*</font>
            <input type="text" name="firstName"  id = "firstName" value="" placeholder="First name only" required="">
            <br>
            <div>
            <label>Last name<font color="red">*</font>
            <input type="text" name="lastName" id = "lastName" value="" placeholder="Last name only" required="">
            <br>
            <div>
            <label>Date of Birth<font color="red">*</font>
            <input type="date" name="dateOfBirth" id = "dateOfBirth" required>
            <br>
			<div>
			
            <label>Email<font color="red">*</font>
            <input type="email" name="email" id = "email" value="" placeholder="example@domain.com" required>
            <br>
			
			<div>
            <label>URL
            <input type="url" name="URL" id = "URL" value="" placeholder="http://mysite.com">
            <br>
            <div>
            <label>Telephone<font color="red">*</font>
            <input type="text" name="contact" id = "contact" value="" placeholder="Eg. +447000 000000" required>
            <br>
            <div>
            <label>Address<font color="red">*</font>
            <input type = "text" name="address" id = "address" placeholder = "1234 ABC Drive" required>
            <br>
            <div>
            <label>Postal code<font color="red">*</font>
            <input type="text" name="zipCode" id = "zipCode" placeholder = "12345" required>
            <br>
            <div>
            <label>Country<font color="red">*</font>
            <input type="text" name="country" id = "country" placeholder = "USA" required>
         </fieldset>
         
		 <fieldset>
            <legend>Academics</legend>
            <div>
            <label>Major<font color="red">*</font>
            <textarea name="major" id="major" rows="7" cols="25" required></textarea>
            
            <!-- Below is the process to make a drop-down menu which would allow you to select a major -->
            <!-- 
               <select>
               <option value="COMSC">Computer Science</option>
               <option value="Math">Mathematics</option>
               <option value="English">English</option>
               <option value="Elec">Elective</option>
               </select> 
               -->

         </fieldset>
         <fieldset>
            <legend>Security</legend>
            <div>
            <label>Password<font color="red">*</font>
            <input type='password'  id='password' placeholder = "Password" maxlength="50"/ required> 
            <br>
            <label>Confirm Password<font color="red">*</font>
            <input type='password'  id='confirm_password' placeholder = "Confirm Password" maxlength="50"/ required> 
            <br>	
			<br>
			<p>Before proceeding, you must read and agree to the <a href="terms_of_service.html" target="_blank">Terms & Conditions</a>.</p>
			  <input type="checkbox" name="tosAgree" required>I have read and agree to the Terms & Conditions.
			<br>
			<br>
            <button type='submit' onclick="validatePassword()"/>Submit</button>
      </form>
      <script type="text/javascript">
         
		 /*
			//Validate all the required (*) fields. The 'required' attribute usually handles this, but it doesn't work in some browsers so this is to improve compatibility with other browsers.
            var frmvalidator  = new Validator("register");
            frmvalidator.EnableOnPageErrorDisplay();
            frmvalidator.EnableMsgsTogether();
            frmvalidator.addValidation("firstName","req","Please provide your first name");
            frmvalidator.addValidation("lastName","req","Please provide your last name");
            frmvalidator.addValidation("dateOfBirth","req","Please provide your date of birth");
            frmvalidator.addValidation("email","req","Please provide your email address");
            frmvalidator.addValidation("contact","req","Please provide contact information");
            frmvalidator.addValidation("address","req","Please provide a valid address");
            frmvalidator.addValidation("zipCode","req","Please provide a zipcode");
            frmvalidator.addValidation("country","req","Please provide a country"); 
            frmvalidator.addValidation("email","email","Please provide a valid email address");
            frmvalidator.addValidation("password","req","Please provide a password");
            frmvalidator.addValidation("confirm_password","req","Please confirm your password");
            frmvalidator.addValidation("major","req","Please pick a major");	
			*/
			
			function validatePassword(){
				
				var password = document.getElementById("password"),
			  confirm_password = document.getElementById("confirm_password");
				
			  if(password.value != confirm_password.value) {
				confirm_password.setCustomValidity("Passwords Don't Match");
			  } else {
				confirm_password.setCustomValidity('');
			  }
			  
			}

			password.onchange = validatePassword;
			confirm_password.onkeyup = validatePassword;
		 </script>
	  </div>
   </body>
</html>