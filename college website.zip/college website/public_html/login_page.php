<!DOCTYPE html>

<?php

	require_once('../private/login.php');

?>
<html>
   <head>
      <link rel="stylesheet" type="text/css" href="css/default_theme.css">
	  <script src='js/default.js'></script>
	  <script>
		loadTheme();
	  </script>
   </head>
   
   <body>
      <div id="page">
		<form id="login" method="POST" accept-charset='UTF-8'>
		<input type="hidden" name="login" value="login"></input>
		  <div style="padding-left:16px">
			 <h2>Login</h2>
		  </div>

		  <fieldset>
			 <div class="container">
			 <center><font color="red"><p id="alert"></p></font></center>
			 <label><b>Username</b></label>
			 <input type="text" placeholder="Enter Username" name="username" id="username" required>
			 <label><b>Password</b></label>
			 <input type="password" placeholder="Enter Password" name="password" id="password" required>
			 <br>   
			 <button type="submit">Login</button>
			 <input type="checkbox" name="rememberMe" id="rememberMe" checked onclick="validate()"> 
			 <label for="rememberMe">Remember me</label>
			 
			 &nbsp
			 <span class="psw">Forgot <a href="lostPassword_page.html">password?</a></span>
			 
			  <p> If you have not registered before, please <a href="registration_page.php">click here!</a></span></p>
	  
		  </fieldset>
		 </form>
      </div>
	  <?php
		require_once('../private/security.php');
		if(isset($_GET['registration']))
		{
			if($_GET['registration']=="success")
			{
				echo "
					<script type=\"text/javascript\">
						var e = document.getElementById('alert');
						e.innerHTML = 'Your Username is ".$_GET['username']."';
					</script>
					";
			
			}
			else if($_GET['login']=="failed")
			{
				echo "
					<script type=\"text/javascript\">
						var e = document.getElementById('alert');
						e.innerHTML = 'Invalid Username or Password. Try again.';
					</script>
					";
			}
		}
	  ?>

   </body>
</html>