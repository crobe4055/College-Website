<!DOCTYPE html>
<html>
   <head>
      <link rel="stylesheet" type="text/css" href="css/default_theme.css">
	  <script src='js/default.js'></script>
	  <script>
		loadTheme();
	  </script>
	  
	  
   </head>
   
   <body>
	 <div id="page">
		<center><img src="class_photo(4).JPG"></center>
	    <script>
			var welcome_txt =
				'<div style="margin-top: 50px; margin-bottom: 50px;"><center>' +
				"<h2>Welcome To " + COLLEGE_NAME + "</h2></br>" +
				"<font size = 4>" +
				"A University that focuses on Science, Technology, Engineering, and Mathematics.<br/>" +
				"Our students are built to become the primary leaders of the world.<br/>" +
				//"We are rated as one of the Top 5 Fake Universities of USA. Right behind Trump University.<br/>"+
				"<p id='account_check'>Interested in becoming a Student at " + COLLEGE_NAME + '? <a href="registration_page.php">Register Here</a><br/>'+
				"Already a Student? " + '<a href="login_page.php">Login Here</a><br/></p>' +
				"</font>" +
				"</center></div>";
		
			document.writeln(welcome_txt);
		</script>
		
	 </div>
	 <?php
		if(isset($_COOKIE['login'])&&$_COOKIE['login']=="success")
		{
			echo "
				<script type=\"text/javascript\">
				var admin='';
				if('{$_COOKIE['admin']}'=='true')
					admin='[Admin]'
				var e = document.getElementById('account_check');
				e.innerHTML = '<br/>Welcome back, ' + admin + ' ".$_COOKIE['username']."<br/>';
					
					
				</script>
				";
			
		}
	 ?>
   </body>
   
</html>   