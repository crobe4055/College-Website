//This Javascript File contains global attributes and functions that will be incorporated to each html file.

const COLLEGE_NAME="FoRoGa University"

//Loads up the theme for the pages. Multiple themes can be used for different reasons
function loadTheme(theme_name="")
{
	var themeHeader='';
	var themeFooter='';
	
	switch(theme_name)
	{
		default:
			//The default theme that will be used for the homepage as well as any other regular pages.
			themeHeader += 
				'<div id="banner"> </div>'+
				'<ul class="topnav" id="myTopnav">'+
					'<li><a class="active" href="index.php">Home</a></li>' +
					'<li><a href="news.html">News</a></li>' +
					'<li><a href="contact.php">Contact</a></li>' +
					'<li><a href="about.html">About</a></li>' +
					'<li><a href="academics.html">Academics</a></li>' +
					'<li><a href="admissions.html">Admissions</a></li>' +
					'<li><a href="locations.html">Locations</a></li>' +
					'<li class="icon">' +
						'<a href="javascript:void(0);" style="font-size:15px;" onclick="topNavResponse()">?</a>' +
					'</li>' +
				 '</ul>';
			 
			 //The footer for the theme. Each page will have this.
			 themeFooter = '<div style="bottom:0px;"><center>Copyrights &copy; 2016, '+COLLEGE_NAME+'</center></div>'
	}
	
	document.writeln(themeHeader);
	
	window.addEventListener('load',function(){document.body.innerHTML+=themeFooter;},false)
}


function topNavResponse()
{
	 var x = document.getElementById("myTopnav");
	 if (x.className === "topnav")
	 {
		 x.className += " responsive";
	 }
	 else
	 {
		 x.className = "topnav";
	 }
 }
